package net.ddns.morigg.homesweethomeapp.structures;

public class Shopping_OneItem
{
    public String item;
    public int status;

    public Shopping_OneItem(String item, int status)
    {
        this.item = item;
        this.status = status;
    }
}
